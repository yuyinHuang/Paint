//��ޤGA 107403011 ��౧u

package HW1_107403011;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null,"Welcome", "�T��", JOptionPane.PLAIN_MESSAGE, new ImageIcon("icon.png"));
		
		Frame frame = new Frame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1000, 600); 
		frame.setVisible(true); 
	    
	    
	}

}

// ��ޤGA 107403011 ��౧u
package HW1_107403011;

import javax.swing.JFrame;

import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.BorderLayout;

import javax.swing.JLabel;

import javax.swing.JComboBox;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

import javax.swing.JCheckBox;
import javax.swing.SwingConstants;

import javax.swing.JButton;

import java.awt.Color;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Frame extends JFrame implements ActionListener {

	private final JPanel SmallPanel;
	private final JPanel BigPanel;

	private final JLabel DrawingTool;
	private final JLabel SizeOfPen;

	private final JLabel SpaceOne;
	private final JLabel SpaceTwo;

	private final JComboBox<String> ComboBox;

	private static final String[] names = { "����", "���u", "����", "�x��", "�ꨤ�x��" };

	private JRadioButton smallJRadioButton;
	private JRadioButton midumJRadioButton;
	private JRadioButton largeJRadioButton;
	private ButtonGroup radioGroup;

	private final JCheckBox fullCheckBox;

	private final JButton colorpenButton;
	private final JButton cleanButton;

	private final JPanel mousePanel;
	private final JLabel statusBar;

	public Frame() {

		super("�p�e�a");

		// �u��C���p���O�A��mJLabel�BComboBox�BRadioButton
		SmallPanel = new JPanel();
		SmallPanel.setLayout(new GridLayout(2, 4, 5, 5));

		// �u��C���j���O�A��m�p���O�BCheckBox�BButton
		BigPanel = new JPanel();
		add(BigPanel, BorderLayout.NORTH);
		BigPanel.add(SmallPanel);

		// ø�Ϥu���r
		DrawingTool = new JLabel("ø�Ϥu��");
		SmallPanel.add(DrawingTool);

		// ����j�p��r
		SizeOfPen = new JLabel("����j�p");
		SmallPanel.add(SizeOfPen);

		// ���FGridLayout���ƪ�
		SpaceOne = new JLabel();
		SpaceOne.setText("\t");
		SmallPanel.add(SpaceOne);

		// ���FGridLayout���ƪ�
		SpaceTwo = new JLabel();
		SpaceTwo.setText("\t");
		SmallPanel.add(SpaceTwo);

		// ø�Ϥu�㪺ComboBox
		ComboBox = new JComboBox<>(names);
		ComboBox.addActionListener(this);
		SmallPanel.add(ComboBox);

		// ����j�p��RadioButton
		smallJRadioButton = new JRadioButton("�p", true);
		midumJRadioButton = new JRadioButton("��", false);
		largeJRadioButton = new JRadioButton("�j", false);

		smallJRadioButton.addActionListener(this);
		midumJRadioButton.addActionListener(this);
		largeJRadioButton.addActionListener(this);

		radioGroup = new ButtonGroup();
		radioGroup.add(smallJRadioButton);
		radioGroup.add(midumJRadioButton);
		radioGroup.add(largeJRadioButton);

		SmallPanel.add(smallJRadioButton);
		SmallPanel.add(midumJRadioButton);
		SmallPanel.add(largeJRadioButton);

		// �񺡪�fullCheckBox
		fullCheckBox = new JCheckBox("��");
		fullCheckBox.setHorizontalTextPosition(SwingConstants.CENTER);
		fullCheckBox.setVerticalTextPosition(SwingConstants.TOP);
		fullCheckBox.addActionListener(this);
		BigPanel.add(fullCheckBox);

		// �����C�⪺Button
		colorpenButton = new JButton("�����C��");
		colorpenButton.addActionListener(this);
		BigPanel.add(colorpenButton);

		// �M���e����Button
		cleanButton = new JButton("�M���e��");
		cleanButton.addActionListener(this);
		BigPanel.add(cleanButton);

		// ��а��������O
		mousePanel = new JPanel();
		mousePanel.setBackground(Color.WHITE);
		add(mousePanel, BorderLayout.CENTER);

		// ��Ц�m��ܪ����A��
		statusBar = new JLabel();
		add(statusBar, BorderLayout.SOUTH);

		// �ƹ�
		MouseHandler handler = new MouseHandler();
		mousePanel.addMouseListener(handler);
		mousePanel.addMouseMotionListener(handler);

	}

	// �ƹ��ƥ�
	private class MouseHandler implements MouseListener, MouseMotionListener {

		public void mouseClicked(MouseEvent event) {
			statusBar.setText(String.format("���Ц�m : (%d, %d)", event.getX(), event.getY()));
		}

		// handle event when mouse pressed
		@Override
		public void mousePressed(MouseEvent event) {
			statusBar.setText(String.format("���Ц�m : (%d, %d)", event.getX(), event.getY()));
		}

		// handle event when mouse released
		@Override
		public void mouseReleased(MouseEvent event) {
			statusBar.setText(String.format("���Ц�m : (%d, %d)", event.getX(), event.getY()));
		}

		// handle event when mouse enters area
		@Override
		public void mouseEntered(MouseEvent event) {
			statusBar.setText(String.format("���Ц�m : (%d, %d)", event.getX(), event.getY()));
		}

		// handle event when mouse exits area
		@Override
		public void mouseExited(MouseEvent event) {
			statusBar.setText("���Ц�m :");

		}

		// MouseMotionListener event handlers
		// handle event when user drags mouse with button pressed
		@Override
		public void mouseDragged(MouseEvent event) {
			statusBar.setText(String.format("���Ц�m : (%d, %d)", event.getX(), event.getY()));
		}

		// handle event when user moves mouse
		@Override
		public void mouseMoved(MouseEvent event) {
			statusBar.setText(String.format("���Ц�m : (%d, %d)", event.getX(), event.getY()));
		}
	}

	//Console�C�L
	@Override
	public void actionPerformed(ActionEvent e) {
		
		boolean isCheck = fullCheckBox.isSelected();
		String comboBoxStatus = names[ComboBox.getSelectedIndex()];

		if (e.getActionCommand().equals("�����C��") || e.getActionCommand().equals("�M���e��"))
			System.out.println("��� " + e.getActionCommand());
		
		else if (e.getActionCommand().equals("�p") || e.getActionCommand().equals("��") || e.getActionCommand().equals("�j"))
			System.out.println("��� " + e.getActionCommand() + " ����");
		
		else if (e.getActionCommand().equals("��"))
			System.out.println((isCheck) ? "��� ��" : "���� ��");
		
		else if (e.getActionCommand().equals("comboBoxChanged"))
			System.out.println("��� " + comboBoxStatus);
	}

}
